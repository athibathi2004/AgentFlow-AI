"""Tool and ToolInvocation database models."""

import enum
import uuid
from datetime import datetime
from typing import Any, Dict, Optional
from sqlalchemy import Boolean, DateTime, Float, ForeignKey, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class ToolStatus(str, enum.Enum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    PENDING_APPROVAL = "PENDING_APPROVAL"


class ToolModel(Base):
    """SQLAlchemy model for registered tools."""

    __tablename__ = "tools"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    schema_json: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    is_sensitive: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    requires_approval: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False, index=True)
    is_mcp: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    mcp_server_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)

    # Relationships
    invocations = relationship("ToolInvocationModel", back_populates="tool")


class ToolInvocationModel(Base):
    """SQLAlchemy model tracking each execution of a tool."""

    __tablename__ = "tool_invocations"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    execution_id: Mapped[Optional[str]] = mapped_column(
        String(36),
        ForeignKey("workflow_executions.id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )
    task_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    tool_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("tools.id", ondelete="CASCADE"), nullable=False, index=True
    )
    agent_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    input_parameters: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    output_result: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    duration_seconds: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relationships
    tool = relationship("ToolModel", back_populates="invocations")
    workflow_execution = relationship("WorkflowExecutionModel", back_populates="tool_invocations")

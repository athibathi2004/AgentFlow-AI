"""Pydantic schemas for Workflows and Tasks."""

from datetime import datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class WorkflowTaskBase(BaseModel):
    task_id: str
    name: str
    description: Optional[str] = None
    assigned_agent_id: Optional[str] = None
    dependencies: List[str] = Field(default_factory=list)
    input_data: Dict[str, Any] = Field(default_factory=dict)
    order_index: int = 0


class WorkflowTaskRead(WorkflowTaskBase):
    id: str
    workflow_id: str
    status: str
    output_data: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class WorkflowCreate(BaseModel):
    name: str = Field(..., min_length=3, max_length=256, description="Workflow name")
    description: Optional[str] = Field(default=None, description="Detailed goal of the workflow")
    task: str = Field(..., min_length=5, description="User prompt or task definition to orchestrate")
    requires_approval: bool = Field(default=False, description="Require human approval before execution starts")


class WorkflowRead(BaseModel):
    id: str
    name: str
    description: Optional[str]
    original_task: str
    status: str
    plan_data: Dict[str, Any]
    requires_approval: bool
    tasks: List[WorkflowTaskRead] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class WorkflowExecuteRequest(BaseModel):
    inputs: Dict[str, Any] = Field(default_factory=dict, description="Runtime inputs overriding or supplementing task")
    force_restart: bool = Field(default=False, description="Restart execution from beginning if already run")


class WorkflowPlanResponse(BaseModel):
    workflow_id: str
    status: str
    tasks: List[Dict[str, Any]]
    execution_order: List[List[str]]
    estimated_steps: int

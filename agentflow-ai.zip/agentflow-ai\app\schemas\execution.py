"""Pydantic schemas for Workflow and Agent Executions."""

from datetime import datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class AgentExecutionRead(BaseModel):
    id: str
    execution_id: str
    workflow_id: str
    task_id: str
    agent_id: Optional[str]
    status: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    input_summary: Optional[str] = None
    output_summary: Optional[str] = None
    error_details: Optional[str] = None
    retry_count: int = 0

    model_config = {"from_attributes": True}


class WorkflowExecutionRead(BaseModel):
    id: str
    workflow_id: str
    status: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    state_data: Dict[str, Any] = Field(default_factory=dict)
    error_message: Optional[str] = None
    retry_count: int = 0
    agent_executions: List[AgentExecutionRead] = Field(default_factory=list)

    model_config = {"from_attributes": True}


class ExecutionSummary(BaseModel):
    id: str
    workflow_id: str
    workflow_name: Optional[str] = None
    status: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    task_count: int = 0
    completed_task_count: int = 0

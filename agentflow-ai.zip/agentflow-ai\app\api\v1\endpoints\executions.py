"""Execution History REST endpoints."""

from typing import Any, List
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import WorkflowNotFoundError
from app.db.session import get_db
from app.schemas.execution import WorkflowExecutionRead
from app.services.workflow_service import WorkflowService

router = APIRouter(prefix="/executions", tags=["Executions"])


def get_workflow_service() -> WorkflowService:
    return WorkflowService()


@router.get(
    "",
    response_model=List[WorkflowExecutionRead],
    summary="List all workflow execution runs",
)
async def list_executions(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    service: WorkflowService = Depends(get_workflow_service),
) -> Any:
    """Retrieve historical workflow execution runs."""
    return await service.list_executions(db, skip=skip, limit=limit)


@router.get(
    "/{execution_id}",
    response_model=WorkflowExecutionRead,
    summary="Get execution run details",
)
async def get_execution(
    execution_id: str,
    db: AsyncSession = Depends(get_db),
    service: WorkflowService = Depends(get_workflow_service),
) -> Any:
    """Retrieve execution state, duration, agent execution breakdown, and errors."""
    try:
        return await service.get_execution_by_id(db, execution_id)
    except WorkflowNotFoundError as ne:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=ne.message,
        )

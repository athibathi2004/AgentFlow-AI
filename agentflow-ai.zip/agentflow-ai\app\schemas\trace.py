"""Pydantic schemas for Execution Traces."""

from datetime import datetime
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field


class ExecutionTraceRead(BaseModel):
    id: str
    workflow_id: str
    execution_id: str
    task_id: Optional[str] = None
    agent_id: Optional[str] = None
    step_name: str
    event_type: str
    timestamp: datetime
    duration_ms: Optional[float] = None
    details_json: Dict[str, Any] = Field(default_factory=dict)
    status: str

    model_config = {"from_attributes": True}


class TraceFilter(BaseModel):
    event_type: Optional[str] = None
    agent_id: Optional[str] = None
    task_id: Optional[str] = None

"""Agent Registry REST endpoints."""

from typing import Any, Dict, List
from fastapi import APIRouter, HTTPException, status
from app.agents.registry import AgentRegistry
from app.core.exceptions import AgentNotFoundError

router = APIRouter(prefix="/agents", tags=["Agents"])


@router.get(
    "",
    response_model=List[Dict[str, Any]],
    summary="List all registered specialized agents",
)
async def list_agents() -> List[Dict[str, Any]]:
    """Retrieve metadata, capabilities, and status for all specialized agents."""
    registry = AgentRegistry.get_instance()
    return registry.list_agents()


@router.get(
    "/{agent_id}",
    response_model=Dict[str, Any],
    summary="Get details of a specific specialized agent",
)
async def get_agent(agent_id: str) -> Dict[str, Any]:
    """Retrieve configuration, system prompt, and schemas for a specific agent."""
    registry = AgentRegistry.get_instance()
    try:
        agent = registry.get(agent_id)
        return agent.get_metadata()
    except AgentNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=e.message,
        )

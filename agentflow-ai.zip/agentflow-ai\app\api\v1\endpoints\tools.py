"""Tool Registry and Execution REST endpoints."""

from typing import Any, Dict, List
from fastapi import APIRouter, HTTPException, status
from app.core.exceptions import ToolNotFoundError
from app.schemas.tool import ToolExecutionRequest, ToolExecutionResponse
from app.tools.registry import ToolRegistry

router = APIRouter(prefix="/tools", tags=["Tools"])


@router.get(
    "",
    response_model=List[Dict[str, Any]],
    summary="List all registered tools",
)
async def list_tools() -> List[Dict[str, Any]]:
    """Retrieve metadata, parameters schemas, and approval requirements for all tools."""
    registry = ToolRegistry.get_instance()
    return registry.list_tools()


@router.post(
    "/{tool_id}/execute",
    response_model=ToolExecutionResponse,
    summary="Directly invoke a registered tool with parameters",
)
async def execute_tool(
    tool_id: str,
    request: ToolExecutionRequest,
) -> Any:
    """Execute a tool with input validation against its Pydantic schema."""
    registry = ToolRegistry.get_instance()
    try:
        res = await registry.execute_tool(
            tool_id=tool_id,
            parameters=request.parameters,
        )
        return ToolExecutionResponse(
            tool_id=res["tool_id"],
            status=res["status"],
            result=res["result"],
            duration_seconds=res["duration_seconds"],
            error=res["error"],
        )
    except ToolNotFoundError as ne:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=ne.message,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Tool execution failed: {str(e)}",
        )

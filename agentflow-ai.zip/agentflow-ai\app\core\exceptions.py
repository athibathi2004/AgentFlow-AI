"""Custom exception definitions for AgentFlow AI."""

from typing import Any, Dict, Optional


class AgentFlowError(Exception):
    """Base exception for all AgentFlow platform errors."""

    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}


class AgentNotFoundError(AgentFlowError):
    """Raised when an agent cannot be resolved by ID or role."""
    pass


class AgentExecutionError(AgentFlowError):
    """Raised when an agent fails to execute its assigned task."""
    pass


class WorkflowNotFoundError(AgentFlowError):
    """Raised when a workflow ID does not exist."""
    pass


class WorkflowExecutionError(AgentFlowError):
    """Raised when workflow orchestration encounters an unrecoverable failure."""
    pass


class WorkflowPlanError(AgentFlowError):
    """Raised when workflow planning or dependency graph is invalid."""
    pass


class ToolNotFoundError(AgentFlowError):
    """Raised when a requested tool is not found in the registry."""
    pass


class ToolExecutionError(AgentFlowError):
    """Raised when a tool execution fails or validation breaks."""
    pass


class ApprovalRequiredError(AgentFlowError):
    """Raised when an action pauses awaiting human approval."""
    pass


class ApprovalNotFoundError(AgentFlowError):
    """Raised when an approval request cannot be located."""
    pass


class MCPError(AgentFlowError):
    """Raised when Model Context Protocol communication or adapter fails."""
    pass

"""Pydantic schemas for Agent entities."""

from datetime import datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class AgentBase(BaseModel):
    name: str = Field(..., description="Display name of the agent")
    role: str = Field(..., description="Functional role (e.g. planner, researcher)")
    description: str = Field(..., description="Detailed description of agent responsibilities")
    capabilities: List[str] = Field(default_factory=list, description="List of agent capabilities")
    is_enabled: bool = Field(default=True, description="Whether agent is active")
    system_prompt: str = Field(..., description="Base system instructions")
    config_json: Dict[str, Any] = Field(default_factory=dict, description="Custom agent configuration")


class AgentCreate(AgentBase):
    id: str = Field(..., description="Unique agent identifier (slug)")


class AgentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    capabilities: Optional[List[str]] = None
    is_enabled: Optional[bool] = None
    system_prompt: Optional[str] = None
    config_json: Optional[Dict[str, Any]] = None


class AgentRead(AgentBase):
    id: str
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}

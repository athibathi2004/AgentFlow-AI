"""System health and diagnostic endpoints."""

import time
from typing import Any, Dict
from fastapi import APIRouter, Depends, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.agents.registry import AgentRegistry
from app.config import settings
from app.db.session import get_db
from app.llm.factory import get_llm_provider
from app.mcp.manager import MCPConnectionManager
from app.tools.registry import ToolRegistry

router = APIRouter(tags=["Health"])

START_TIME = time.time()


@router.get(
    "/health",
    status_code=status.HTTP_200_OK,
    summary="System Health & Diagnostic Status",
    response_description="Operational metrics and connectivity health.",
)
async def get_system_health(
    db: AsyncSession = Depends(get_db),
) -> Dict[str, Any]:
    """Return health metrics for Database, LLM backend, MCP servers, and registries."""
    uptime_seconds = round(time.time() - START_TIME, 2)

    # 1. Check DB connectivity
    db_status = "HEALTHY"
    try:
        await db.execute(text("SELECT 1"))
    except Exception as e:
        db_status = f"UNHEALTHY ({str(e)})"

    # 2. Check LLM Provider status
    llm = get_llm_provider()
    llm_available = await llm.is_available()

    # 3. Registries
    agent_reg = AgentRegistry.get_instance()
    tool_reg = ToolRegistry.get_instance()
    mcp_mgr = MCPConnectionManager.get_instance()
    mcp_servers = await mcp_mgr.list_servers()

    return {
        "status": "healthy" if db_status == "HEALTHY" else "degraded",
        "project": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "uptime_seconds": uptime_seconds,
        "database": {
            "status": db_status,
            "engine": "sqlite" if "sqlite" in settings.DATABASE_URL else "postgresql",
        },
        "llm_provider": {
            "type": llm.provider_name,
            "model": llm.model_name,
            "available": llm_available,
        },
        "agents": {
            "total_registered": len(agent_reg.list_agents()),
            "enabled": sum(1 for a in agent_reg.list_agents() if a.get("is_enabled")),
        },
        "tools": {
            "total_registered": len(tool_reg.list_tools()),
            "mcp_tools": sum(1 for t in tool_reg.list_tools() if t.get("is_mcp")),
        },
        "mcp": {
            "servers_count": len(mcp_servers),
            "servers": mcp_servers,
        },
    }

"""Analysis Agent implementation."""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from app.agents.base import BaseAgent
from app.llm.base import BaseLLMProvider


class AnalysisInput(BaseModel):
    research_summary: Optional[str] = Field(default="", description="Summary of evidence gathered by researcher")
    findings: List[Dict[str, Any]] = Field(default_factory=list, description="List of research findings")
    parameters: Dict[str, Any] = Field(default_factory=dict, description="Analytical parameters or metric targets")


class RiskAssessment(BaseModel):
    risk_factor: str
    severity: str  # "LOW" | "MEDIUM" | "HIGH"
    mitigation: str


class AnalysisOutput(BaseModel):
    summary: str
    quantitative_metrics: Dict[str, Any]
    strategic_insights: List[str]
    risks: List[RiskAssessment]
    recommendation: str


class AnalysisAgent(BaseAgent):
    """Specialized Agent responsible for quantitative evaluation, metric validation, and risk analysis."""

    id = "analysis-agent"
    name = "Analysis Agent"
    role = "analyst"
    description = (
        "Performs quantitative evaluation, calculates statistical metrics using safe calculation tools, "
        "and synthesizes trade-offs, risks, and strategic recommendations."
    )
    capabilities = [
        "quantitative_analysis",
        "metric_calculation",
        "risk_assessment",
        "tradeoff_evaluation",
    ]
    system_prompt = (
        "You are the Analysis Agent of AgentFlow AI. Your mandate is to critically examine research findings, "
        "compute quantitative metrics, identify systemic risks, and provide objective analytical assessments."
    )
    input_schema = AnalysisInput
    output_schema = AnalysisOutput

    def __init__(self, llm_provider: Optional[BaseLLMProvider] = None):
        super().__init__(llm_provider=llm_provider)

    async def process(
        self,
        validated_input: BaseModel,
        context: Dict[str, Any],
        tool_calls: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        inp: AnalysisInput = validated_input  # type: ignore

        # 1. Use calculator tool to compute a sample quantitative ROI or efficiency index
        calc_res = await self.call_tool(
            tool_id="calculator",
            parameters={"expression": "round((100 - 26) * 1.0, 2)"},
            recorded_calls=tool_calls,
        )
        calculated_efficiency = calc_res.get("value", 74.0)

        # 2. Evaluate research findings
        findings_count = len(inp.findings)
        insights = [
            f"Evaluated {max(findings_count, 1)} primary evidence streams for architectural feasibility.",
            f"Standardized tool integration demonstrates estimated {calculated_efficiency}% operational efficiency gains.",
            "State machine checkpointing prevents cascading errors across distributed agent steps.",
        ]

        risks = [
            {
                "risk_factor": "Tool Schema Drift",
                "severity": "MEDIUM",
                "mitigation": "Strict Pydantic v2 validation contracts on all tool inputs and outputs.",
            },
            {
                "risk_factor": "Unbounded LLM Generation Latency",
                "severity": "LOW",
                "mitigation": "Configurable per-step execution timeouts and exponential backoff retries.",
            },
        ]

        if self.llm:
            prompt = (
                f"Research Summary: {inp.research_summary}\n"
                f"Findings: {inp.findings}\n"
                f"Computed Metric: {calculated_efficiency}\n\n"
                "Provide a rigorous quantitative analysis, strategic insights, and risk assessments."
            )
            raw = await self.llm.generate_structured(
                prompt=prompt,
                response_schema=AnalysisOutput,
                system_prompt=self.system_prompt,
            )
            if "strategic_insights" in raw and raw["strategic_insights"]:
                return {
                    "summary": raw.get("summary", "Analytical evaluation completed successfully."),
                    "quantitative_metrics": raw.get(
                        "quantitative_metrics",
                        {"efficiency_gain_pct": calculated_efficiency, "evidence_items_analyzed": findings_count},
                    ),
                    "strategic_insights": raw["strategic_insights"],
                    "risks": raw.get("risks", risks),
                    "recommendation": raw.get("recommendation", "Proceed with phased execution."),
                }

        return {
            "summary": f"Analytical evaluation concluded. Identified {len(insights)} core insights and {len(risks)} manageable risk vectors.",
            "quantitative_metrics": {
                "efficiency_gain_pct": calculated_efficiency,
                "evidence_items_analyzed": findings_count,
                "risk_index": 0.25,
            },
            "strategic_insights": insights,
            "risks": risks,
            "recommendation": "Adopt LangGraph state graphs with human approval checkpoints for critical operations.",
        }

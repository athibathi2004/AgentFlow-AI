"""Approvals module exports."""

from app.approvals.service import ApprovalService

__all__ = ["ApprovalService"]

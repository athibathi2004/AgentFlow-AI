"""Human-in-the-Loop Approval Service."""

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import ApprovalNotFoundError
from app.core.logging import get_logger
from app.models.approval import ApprovalRequestModel, ApprovalStatus, ApprovalType

logger = get_logger(__name__)


class ApprovalService:
    """Service managing human approval checkpoints, queues, and decisions."""

    @staticmethod
    async def create_request(
        db: AsyncSession,
        workflow_id: str,
        request_type: str,
        details: Dict[str, Any],
        execution_id: Optional[str] = None,
        task_id: Optional[str] = None,
        tool_id: Optional[str] = None,
    ) -> ApprovalRequestModel:
        """Create and persist a pending approval request."""
        req = ApprovalRequestModel(
            id=str(uuid.uuid4()),
            workflow_id=workflow_id,
            execution_id=execution_id,
            task_id=task_id,
            tool_id=tool_id,
            request_type=request_type,
            status=ApprovalStatus.PENDING.value,
            details_json=details,
        )
        db.add(req)
        await db.commit()
        await db.refresh(req)
        logger.info(f"Created approval request {req.id} ({request_type}) for workflow {workflow_id}")
        return req

    @staticmethod
    async def resolve_request(
        db: AsyncSession,
        approval_id: str,
        approved: bool,
        notes: Optional[str] = None,
    ) -> ApprovalRequestModel:
        """Approve or reject a pending request."""
        stmt = select(ApprovalRequestModel).where(ApprovalRequestModel.id == approval_id)
        result = await db.execute(stmt)
        req = result.scalar_one_or_none()
        if not req:
            raise ApprovalNotFoundError(f"Approval request '{approval_id}' not found")

        req.status = ApprovalStatus.APPROVED.value if approved else ApprovalStatus.REJECTED.value
        req.reviewer_notes = notes
        req.resolved_at = datetime.now(timezone.utc)
        await db.commit()
        await db.refresh(req)
        logger.info(f"Resolved approval request {approval_id} -> {req.status}")
        return req

    @staticmethod
    async def get_pending_approvals(db: AsyncSession) -> List[ApprovalRequestModel]:
        """List all currently pending approval requests across workflows."""
        stmt = (
            select(ApprovalRequestModel)
            .where(ApprovalRequestModel.status == ApprovalStatus.PENDING.value)
            .order_by(desc(ApprovalRequestModel.created_at))
        )
        result = await db.execute(stmt)
        return list(result.scalars().all())

    @staticmethod
    async def get_by_id(db: AsyncSession, approval_id: str) -> ApprovalRequestModel:
        """Get approval request by ID."""
        stmt = select(ApprovalRequestModel).where(ApprovalRequestModel.id == approval_id)
        result = await db.execute(stmt)
        req = result.scalar_one_or_none()
        if not req:
            raise ApprovalNotFoundError(f"Approval request '{approval_id}' not found")
        return req

"""Multi-Agent Orchestrator: coordinates LangGraph execution, retries, and persistence."""

import asyncio
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.agents.registry import AgentRegistry
from app.approvals.service import ApprovalService
from app.config import settings
from app.core.exceptions import (
    AgentExecutionError,
    WorkflowExecutionError,
    WorkflowNotFoundError,
)
from app.core.logging import get_logger
from app.models.approval import ApprovalStatus, ApprovalType
from app.models.execution import (
    AgentExecutionModel,
    ExecutionStatus,
    WorkflowExecutionModel,
)
from app.models.tool import ToolInvocationModel, ToolStatus
from app.models.trace import TraceEventType
from app.models.workflow import TaskStatus, WorkflowModel, WorkflowStatus
from app.orchestration.graph import create_agent_workflow_graph
from app.orchestration.state import WorkflowState
from app.tracing.service import ExecutionTraceService

logger = get_logger(__name__)


class MultiAgentOrchestrator:
    """Core Orchestrator coordinating multi-agent pipeline execution and persistence."""

    def __init__(self, agent_registry: Optional[AgentRegistry] = None):
        self.registry = agent_registry or AgentRegistry.get_instance()
        self.graph = create_agent_workflow_graph(self.registry)

    async def execute_workflow(
        self,
        db: AsyncSession,
        workflow_id: str,
        inputs: Optional[Dict[str, Any]] = None,
        force_restart: bool = False,
    ) -> WorkflowExecutionModel:
        """Start or resume a workflow execution run."""
        # 1. Fetch workflow
        stmt = select(WorkflowModel).where(WorkflowModel.id == workflow_id)
        res = await db.execute(stmt)
        workflow = res.scalar_one_or_none()
        if not workflow:
            raise WorkflowNotFoundError(f"Workflow '{workflow_id}' does not exist")

        is_already_approved = (workflow.status == WorkflowStatus.APPROVED.value)

        # 2. Create WorkflowExecution record
        now = datetime.now(timezone.utc)
        execution_id = str(uuid.uuid4())
        execution = WorkflowExecutionModel(
            id=execution_id,
            workflow_id=workflow_id,
            status=ExecutionStatus.RUNNING.value,
            started_at=now,
            state_data={"inputs": inputs or {}},
            retry_count=0,
        )
        db.add(execution)
        workflow.status = WorkflowStatus.RUNNING.value
        await db.commit()
        await db.refresh(execution)

        # Record start trace
        await ExecutionTraceService.record_trace(
            db=db,
            workflow_id=workflow_id,
            execution_id=execution_id,
            step_name="workflow_init",
            event_type=TraceEventType.WORKFLOW_START.value,
            details={"task": workflow.original_task, "requires_approval": workflow.requires_approval},
            status="INFO",
        )

        # 3. Check if plan approval is pending
        if workflow.requires_approval and not is_already_approved:
            # Check for existing approval
            app_req = await ApprovalService.create_request(
                db=db,
                workflow_id=workflow_id,
                execution_id=execution_id,
                request_type=ApprovalType.WORKFLOW_PLAN.value,
                details={
                    "plan": workflow.plan_data,
                    "original_task": workflow.original_task,
                },
            )
            execution.status = ExecutionStatus.PAUSED.value
            workflow.status = WorkflowStatus.PENDING_APPROVAL.value
            await db.commit()

            await ExecutionTraceService.record_trace(
                db=db,
                workflow_id=workflow_id,
                execution_id=execution_id,
                step_name="approval_gate",
                event_type=TraceEventType.APPROVAL_REQUEST.value,
                details={"approval_id": app_req.id, "reason": "Workflow requires plan approval"},
                status="WARNING",
            )
            return execution

        # 4. Initialize LangGraph State
        initial_state: WorkflowState = {
            "workflow_id": workflow_id,
            "execution_id": execution_id,
            "original_task": workflow.original_task,
            "plan": workflow.plan_data,
            "current_step": "init",
            "completed_steps": [],
            "step_results": {},
            "agent_outputs": {},
            "tool_invocations": [],
            "requires_approval": False if is_already_approved else workflow.requires_approval,
            "approval_status": "APPROVED" if is_already_approved else ("NOT_REQUIRED" if not workflow.requires_approval else "PENDING"),
            "errors": [],
            "retry_counts": {},
            "final_output": {},
            "status": "RUNNING",
        }

        # 5. Run Graph
        start_clock = time.perf_counter()
        try:
            final_state = await self.graph.ainvoke(initial_state)
            duration = round(time.perf_counter() - start_clock, 4)

            # Persist tool calls made during execution
            for t_call in final_state.get("tool_invocations", []):
                tool_inv = ToolInvocationModel(
                    execution_id=execution_id,
                    tool_id=t_call.get("tool_id", "unknown"),
                    input_parameters=t_call.get("parameters", {}),
                    output_result=t_call.get("result", {}),
                    status=ToolStatus.SUCCESS.value if t_call.get("status") == "SUCCESS" else ToolStatus.FAILED.value,
                    started_at=now,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=t_call.get("duration_seconds", 0.0),
                    error_message=t_call.get("error"),
                )
                db.add(tool_inv)

                await ExecutionTraceService.record_trace(
                    db=db,
                    workflow_id=workflow_id,
                    execution_id=execution_id,
                    step_name=f"tool_{t_call.get('tool_id')}",
                    event_type=TraceEventType.TOOL_CALL.value,
                    duration_ms=(t_call.get("duration_seconds", 0.0) or 0.0) * 1000,
                    details=t_call,
                    status="SUCCESS" if t_call.get("status") == "SUCCESS" else "FAILED",
                )

            # Persist individual Agent Execution records
            for agent_role, agent_output in final_state.get("agent_outputs", {}).items():
                agent_exec = AgentExecutionModel(
                    execution_id=execution_id,
                    workflow_id=workflow_id,
                    task_id=f"step_{agent_role}",
                    agent_id=agent_role,
                    status=ExecutionStatus.COMPLETED.value,
                    started_at=now,
                    completed_at=datetime.now(timezone.utc),
                    duration_seconds=round(duration / max(len(final_state.get("agent_outputs", {})), 1), 3),
                    input_summary=workflow.original_task[:120],
                    output_summary=str(agent_output)[:200],
                )
                db.add(agent_exec)

                await ExecutionTraceService.record_trace(
                    db=db,
                    workflow_id=workflow_id,
                    execution_id=execution_id,
                    step_name=f"agent_{agent_role}",
                    event_type=TraceEventType.AGENT_INVOKE.value,
                    agent_id=agent_role,
                    details={"output_summary": agent_output},
                    status="SUCCESS",
                )

            # Update Execution status
            if final_state.get("status") == "PAUSED":
                execution.status = ExecutionStatus.PAUSED.value
                workflow.status = WorkflowStatus.PAUSED.value
            else:
                execution.status = ExecutionStatus.COMPLETED.value
                workflow.status = WorkflowStatus.COMPLETED.value

            execution.completed_at = datetime.now(timezone.utc)
            execution.duration_seconds = duration
            execution.state_data = dict(final_state)

            await db.commit()
            await db.refresh(execution)

            await ExecutionTraceService.record_trace(
                db=db,
                workflow_id=workflow_id,
                execution_id=execution_id,
                step_name="workflow_complete",
                event_type=TraceEventType.WORKFLOW_END.value,
                duration_ms=duration * 1000,
                details={"status": execution.status},
                status="SUCCESS",
            )
            return execution

        except Exception as e:
            duration = round(time.perf_counter() - start_clock, 4)
            err_msg = str(e)
            logger.error(f"Execution error in workflow {workflow_id}: {err_msg}", exc_info=True)

            execution.status = ExecutionStatus.FAILED.value
            execution.completed_at = datetime.now(timezone.utc)
            execution.duration_seconds = duration
            execution.error_message = err_msg
            workflow.status = WorkflowStatus.FAILED.value
            await db.commit()

            await ExecutionTraceService.record_trace(
                db=db,
                workflow_id=workflow_id,
                execution_id=execution_id,
                step_name="workflow_failure",
                event_type=TraceEventType.ERROR.value,
                duration_ms=duration * 1000,
                details={"error": err_msg},
                status="FAILED",
            )
            return execution

    async def resume_workflow(
        self,
        db: AsyncSession,
        workflow_id: str,
        notes: Optional[str] = None,
    ) -> WorkflowExecutionModel:
        """Resume a paused workflow after approval."""
        stmt = select(WorkflowModel).where(WorkflowModel.id == workflow_id)
        res = await db.execute(stmt)
        workflow = res.scalar_one_or_none()
        if not workflow:
            raise WorkflowNotFoundError(f"Workflow '{workflow_id}' not found")

        workflow.status = WorkflowStatus.APPROVED.value
        await db.commit()

        # Execute remaining pipeline
        return await self.execute_workflow(db, workflow_id, inputs={"resume_notes": notes})

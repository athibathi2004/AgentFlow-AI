"""Shared Workflow State definition for LangGraph multi-agent orchestration."""

from typing import Any, Dict, List, Optional
from typing_extensions import TypedDict


class WorkflowState(TypedDict, total=False):
    """Central state passed across all nodes in the LangGraph orchestration pipeline."""

    workflow_id: str
    execution_id: str
    original_task: str
    plan: Dict[str, Any]
    current_step: str
    completed_steps: List[str]
    step_results: Dict[str, Any]
    agent_outputs: Dict[str, Any]
    tool_invocations: List[Dict[str, Any]]
    requires_approval: bool
    approval_status: str  # "NONE" | "PENDING" | "APPROVED" | "REJECTED"
    approval_id: Optional[str]
    errors: List[str]
    retry_counts: Dict[str, int]
    final_output: Dict[str, Any]
    status: str  # "PENDING" | "RUNNING" | "COMPLETED" | "FAILED" | "PAUSED"

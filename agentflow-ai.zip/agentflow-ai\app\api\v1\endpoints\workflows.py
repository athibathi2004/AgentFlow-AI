"""Workflow orchestration REST endpoints."""

from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.exceptions import (
    ApprovalNotFoundError,
    WorkflowExecutionError,
    WorkflowNotFoundError,
    WorkflowPlanError,
)
from app.db.session import get_db
from app.schemas.approval import ApprovalActionRequest
from app.schemas.execution import WorkflowExecutionRead
from app.schemas.trace import ExecutionTraceRead
from app.schemas.workflow import (
    WorkflowCreate,
    WorkflowExecuteRequest,
    WorkflowRead,
)
from app.services.workflow_service import WorkflowService

router = APIRouter(prefix="/workflows", tags=["Workflows"])


def get_workflow_service() -> WorkflowService:
    return WorkflowService()


@router.post(
    "",
    response_model=WorkflowRead,
    status_code=status.HTTP_201_CREATED,
    summary="Create and plan a new multi-agent workflow",
)
async def create_workflow(
    payload: WorkflowCreate,
    db: AsyncSession = Depends(get_db),
    service: WorkflowService = Depends(get_workflow_service),
) -> Any:
    """Submit a complex task, decompose it into subtasks, and persist the execution plan."""
    try:
        workflow = await service.create_workflow(db, payload)
        return workflow
    except WorkflowPlanError as pe:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=pe.message,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create workflow: {str(e)}",
        )


@router.get(
    "",
    response_model=List[WorkflowRead],
    summary="List all workflows",
)
async def list_workflows(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    service: WorkflowService = Depends(get_workflow_service),
) -> Any:
    """Retrieve paginated list of created workflows."""
    return await service.list_workflows(db, skip=skip, limit=limit)


@router.get(
    "/{workflow_id}",
    response_model=WorkflowRead,
    summary="Get workflow details and subtasks",
)
async def get_workflow(
    workflow_id: str,
    db: AsyncSession = Depends(get_db),
    service: WorkflowService = Depends(get_workflow_service),
) -> Any:
    """Retrieve workflow metadata, execution plan, and subtasks."""
    try:
        return await service.get_workflow(db, workflow_id)
    except WorkflowNotFoundError as ne:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=ne.message,
        )


@router.post(
    "/{workflow_id}/execute",
    response_model=WorkflowExecutionRead,
    summary="Execute multi-agent workflow pipeline",
)
async def execute_workflow(
    workflow_id: str,
    request: WorkflowExecuteRequest = WorkflowExecuteRequest(),
    db: AsyncSession = Depends(get_db),
    service: WorkflowService = Depends(get_workflow_service),
) -> Any:
    """Trigger the LangGraph multi-agent execution pipeline for the given workflow."""
    try:
        execution = await service.execute_workflow(
            db=db,
            workflow_id=workflow_id,
            inputs=request.inputs,
            force_restart=request.force_restart,
        )
        return execution
    except WorkflowNotFoundError as ne:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=ne.message,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Execution failed: {str(e)}",
        )


@router.post(
    "/{workflow_id}/approve",
    response_model=Dict[str, Any],
    summary="Approve workflow plan or sensitive action",
)
async def approve_workflow(
    workflow_id: str,
    action: ApprovalActionRequest = ApprovalActionRequest(),
    db: AsyncSession = Depends(get_db),
    service: WorkflowService = Depends(get_workflow_service),
) -> Any:
    """Human-in-the-Loop checkpoint: approve workflow execution and resume if paused."""
    try:
        return await service.approve_workflow(
            db=db,
            workflow_id=workflow_id,
            notes=action.notes,
        )
    except WorkflowNotFoundError as ne:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=ne.message,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Approval resolution error: {str(e)}",
        )


@router.post(
    "/{workflow_id}/reject",
    response_model=Dict[str, Any],
    summary="Reject workflow plan",
)
async def reject_workflow(
    workflow_id: str,
    action: ApprovalActionRequest = ApprovalActionRequest(),
    db: AsyncSession = Depends(get_db),
    service: WorkflowService = Depends(get_workflow_service),
) -> Any:
    """Human-in-the-Loop checkpoint: reject workflow plan with optional reviewer notes."""
    try:
        return await service.reject_workflow(
            db=db,
            workflow_id=workflow_id,
            notes=action.notes,
        )
    except WorkflowNotFoundError as ne:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=ne.message,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Rejection resolution error: {str(e)}",
        )


@router.get(
    "/{workflow_id}/traces",
    response_model=List[ExecutionTraceRead],
    summary="Retrieve execution traces for a workflow",
)
async def get_workflow_traces(
    workflow_id: str,
    db: AsyncSession = Depends(get_db),
    service: WorkflowService = Depends(get_workflow_service),
) -> Any:
    """Fetch chronological execution trace events for auditability and debugging."""
    try:
        # Verify workflow existence
        await service.get_workflow(db, workflow_id)
        return await service.get_traces(db, workflow_id)
    except WorkflowNotFoundError as ne:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=ne.message,
        )

"""LangGraph StateGraph builder for AgentFlow AI multi-agent orchestration."""

import asyncio
from typing import Any, Dict, Literal
from langgraph.graph import END, START, StateGraph
from app.agents.registry import AgentRegistry
from app.core.logging import get_logger
from app.orchestration.state import WorkflowState

logger = get_logger(__name__)


def create_agent_workflow_graph(agent_registry: AgentRegistry) -> Any:
    """Build and compile the LangGraph StateGraph for multi-agent execution."""

    async def planner_node(state: WorkflowState) -> Dict[str, Any]:
        """Node 1: Planner Agent decomposes or verifies workflow plan."""
        logger.info(f"Executing planner_node for workflow: {state.get('workflow_id')}")
        agent = agent_registry.get("planner-agent")

        # If plan is already created, pass through
        if state.get("plan") and state["plan"].get("tasks"):
            return {
                "current_step": "plan_verified",
                "completed_steps": list(set(state.get("completed_steps", []) + ["planner"])),
            }

        res = await agent.execute(
            input_data={"task": state.get("original_task", "")},
            context={"workflow_id": state.get("workflow_id")},
        )
        return {
            "plan": res.output_data,
            "current_step": "plan_created",
            "completed_steps": list(set(state.get("completed_steps", []) + ["planner"])),
            "tool_invocations": state.get("tool_invocations", []) + res.tool_calls,
        }

    async def approval_gate_node(state: WorkflowState) -> Dict[str, Any]:
        """Node 2: Human-in-the-Loop approval gate."""
        requires_approval = state.get("requires_approval", False)
        approval_status = state.get("approval_status", "NONE")

        if requires_approval and approval_status != "APPROVED":
            logger.info(f"Workflow {state.get('workflow_id')} paused at approval_gate_node")
            return {
                "status": "PAUSED",
                "current_step": "approval_pending",
                "approval_status": "PENDING",
            }
        return {
            "current_step": "approval_cleared",
            "approval_status": "APPROVED" if requires_approval else "NOT_REQUIRED",
        }

    async def research_node(state: WorkflowState) -> Dict[str, Any]:
        """Node 3: Research Agent retrieves empirical facts and document evidence."""
        logger.info(f"Executing research_node for workflow: {state.get('workflow_id')}")
        agent = agent_registry.get("research-agent")
        task_query = state.get("original_task", "")

        res = await agent.execute(
            input_data={"query": task_query},
            context={"workflow_id": state.get("workflow_id")},
        )
        step_results = dict(state.get("step_results", {}))
        step_results["research"] = res.output_data

        agent_outputs = dict(state.get("agent_outputs", {}))
        agent_outputs["research-agent"] = res.output_summary

        return {
            "step_results": step_results,
            "agent_outputs": agent_outputs,
            "current_step": "research_completed",
            "completed_steps": list(set(state.get("completed_steps", []) + ["researcher"])),
            "tool_invocations": state.get("tool_invocations", []) + res.tool_calls,
        }

    async def analysis_node(state: WorkflowState) -> Dict[str, Any]:
        """Node 4: Analysis Agent computes metrics and evaluates risks."""
        logger.info(f"Executing analysis_node for workflow: {state.get('workflow_id')}")
        agent = agent_registry.get("analysis-agent")
        research_data = state.get("step_results", {}).get("research", {})

        res = await agent.execute(
            input_data={
                "research_summary": research_data.get("summary", ""),
                "findings": research_data.get("findings", []),
            },
            context={"workflow_id": state.get("workflow_id")},
        )
        step_results = dict(state.get("step_results", {}))
        step_results["analysis"] = res.output_data

        agent_outputs = dict(state.get("agent_outputs", {}))
        agent_outputs["analysis-agent"] = res.output_summary

        return {
            "step_results": step_results,
            "agent_outputs": agent_outputs,
            "current_step": "analysis_completed",
            "completed_steps": list(set(state.get("completed_steps", []) + ["analyst"])),
            "tool_invocations": state.get("tool_invocations", []) + res.tool_calls,
        }

    async def writer_node(state: WorkflowState) -> Dict[str, Any]:
        """Node 5: Writer Agent authors the deliverable report."""
        logger.info(f"Executing writer_node for workflow: {state.get('workflow_id')}")
        agent = agent_registry.get("writer-agent")
        research_data = state.get("step_results", {}).get("research", {})
        analysis_data = state.get("step_results", {}).get("analysis", {})

        res = await agent.execute(
            input_data={
                "original_task": state.get("original_task", ""),
                "research_summary": research_data.get("summary", ""),
                "analysis_insights": analysis_data.get("strategic_insights", []),
                "metrics": analysis_data.get("quantitative_metrics", {}),
            },
            context={"workflow_id": state.get("workflow_id")},
        )
        step_results = dict(state.get("step_results", {}))
        step_results["writer"] = res.output_data

        agent_outputs = dict(state.get("agent_outputs", {}))
        agent_outputs["writer-agent"] = res.output_summary

        return {
            "step_results": step_results,
            "agent_outputs": agent_outputs,
            "current_step": "writing_completed",
            "completed_steps": list(set(state.get("completed_steps", []) + ["writer"])),
            "tool_invocations": state.get("tool_invocations", []) + res.tool_calls,
        }

    async def reviewer_node(state: WorkflowState) -> Dict[str, Any]:
        """Node 6: Reviewer Agent audits and scores the drafted report."""
        logger.info(f"Executing reviewer_node for workflow: {state.get('workflow_id')}")
        agent = agent_registry.get("reviewer-agent")
        writer_data = state.get("step_results", {}).get("writer", {})
        content = writer_data.get("markdown_content", "")

        res = await agent.execute(
            input_data={
                "original_task": state.get("original_task", ""),
                "document_content": content,
            },
            context={"workflow_id": state.get("workflow_id")},
        )
        step_results = dict(state.get("step_results", {}))
        step_results["reviewer"] = res.output_data

        agent_outputs = dict(state.get("agent_outputs", {}))
        agent_outputs["reviewer-agent"] = res.output_summary

        return {
            "step_results": step_results,
            "agent_outputs": agent_outputs,
            "current_step": "review_completed",
            "completed_steps": list(set(state.get("completed_steps", []) + ["reviewer"])),
            "tool_invocations": state.get("tool_invocations", []) + res.tool_calls,
        }

    async def consolidate_output_node(state: WorkflowState) -> Dict[str, Any]:
        """Node 7: Orchestrator consolidates final response and execution artifacts."""
        logger.info(f"Consolidating final response for workflow: {state.get('workflow_id')}")
        step_results = state.get("step_results", {})
        writer_data = step_results.get("writer", {})
        reviewer_data = step_results.get("reviewer", {})

        final_payload = {
            "title": writer_data.get("title", "Execution Deliverable"),
            "report_markdown": writer_data.get("markdown_content", ""),
            "review_score": reviewer_data.get("score", 100),
            "review_verdict": reviewer_data.get("verdict", "APPROVED"),
            "completed_stages": state.get("completed_steps", []),
            "total_tools_invoked": len(state.get("tool_invocations", [])),
        }

        return {
            "final_output": final_payload,
            "status": "COMPLETED",
            "current_step": "completed",
        }

    # Conditional Routing Logic
    def route_after_approval(state: WorkflowState) -> Literal["research", "end"]:
        """Route to research if approved, or terminate early if paused/rejected."""
        if state.get("status") == "PAUSED":
            return "end"
        if state.get("approval_status") == "REJECTED":
            return "end"
        return "research"

    def route_after_review(state: WorkflowState) -> Literal["consolidate", "writer"]:
        """Check review score: if >= 80 proceed to consolidate; if below and retry count < 2, retry writer."""
        reviewer_data = state.get("step_results", {}).get("reviewer", {})
        score = reviewer_data.get("score", 100)
        retries = state.get("retry_counts", {}).get("writer", 0)

        if score < 80 and retries < 2:
            logger.warning(f"Review score {score} < 80. Retrying writer node (attempt {retries + 1})")
            retry_counts = dict(state.get("retry_counts", {}))
            retry_counts["writer"] = retries + 1
            state["retry_counts"] = retry_counts
            return "writer"
        return "consolidate"

    # Construct StateGraph
    workflow_graph = StateGraph(WorkflowState)

    # Add Nodes
    workflow_graph.add_node("planner", planner_node)
    workflow_graph.add_node("approval_gate", approval_gate_node)
    workflow_graph.add_node("research", research_node)
    workflow_graph.add_node("analysis", analysis_node)
    workflow_graph.add_node("writer", writer_node)
    workflow_graph.add_node("reviewer", reviewer_node)
    workflow_graph.add_node("consolidate", consolidate_output_node)

    # Add Edges
    workflow_graph.add_edge(START, "planner")
    workflow_graph.add_edge("planner", "approval_gate")
    workflow_graph.add_conditional_edges(
        "approval_gate",
        route_after_approval,
        {"research": "research", "end": END},
    )
    workflow_graph.add_edge("research", "analysis")
    workflow_graph.add_edge("analysis", "writer")
    workflow_graph.add_edge("writer", "reviewer")
    workflow_graph.add_conditional_edges(
        "reviewer",
        route_after_review,
        {"consolidate": "consolidate", "writer": "writer"},
    )
    workflow_graph.add_edge("consolidate", END)

    # Compile Graph
    return workflow_graph.compile()

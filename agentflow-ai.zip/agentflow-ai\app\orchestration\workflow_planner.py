"""Workflow Planner service: task decomposition, DAG cycle detection, and topological sorting."""

from typing import Any, Dict, List, Set
from app.agents.planner import PlannerAgent
from app.agents.registry import AgentRegistry
from app.core.exceptions import WorkflowPlanError
from app.core.logging import get_logger

logger = get_logger(__name__)


class WorkflowPlanner:
    """Service that transforms user objectives into verified execution plans with dependency resolution."""

    def __init__(self, planner_agent: PlannerAgent, agent_registry: AgentRegistry):
        self.planner = planner_agent
        self.registry = agent_registry

    async def create_plan(
        self,
        task: str,
        parameters: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:
        """Generate structured subtasks and validate the resulting execution DAG."""
        res = await self.planner.execute(
            input_data={"task": task, "parameters": parameters or {}},
            context={"action": "plan_creation"},
        )
        if res.status != "SUCCESS":
            raise WorkflowPlanError(f"Planner agent failed to generate plan: {res.error}")

        plan_data = res.output_data
        tasks = plan_data.get("tasks", [])

        # Validate tasks
        self.validate_plan_structure(tasks)

        # Compute topological layers for execution
        execution_stages = self.compute_execution_order(tasks)

        return {
            "summary": plan_data.get("summary", f"Plan for {task[:60]}"),
            "strategic_objective": plan_data.get("strategic_objective", task),
            "tasks": tasks,
            "execution_stages": execution_stages,
            "estimated_duration_seconds": plan_data.get("estimated_duration_seconds", 15),
        }

    def validate_plan_structure(self, tasks: List[Dict[str, Any]]) -> None:
        """Validate tasks list for completeness, unique IDs, agent existence, and no cycle."""
        if not tasks:
            raise WorkflowPlanError("Workflow plan must contain at least one subtask")

        task_ids: Set[str] = set()
        for idx, t in enumerate(tasks):
            t_id = t.get("task_id")
            if not t_id:
                raise WorkflowPlanError(f"Task at index {idx} is missing a 'task_id'")
            if t_id in task_ids:
                raise WorkflowPlanError(f"Duplicate task identifier '{t_id}' in plan")
            task_ids.add(t_id)

            agent_id = t.get("assigned_agent_id")
            if agent_id and not self.registry.exists(agent_id):
                raise WorkflowPlanError(
                    f"Task '{t_id}' assigned to unregistered agent '{agent_id}'"
                )

        # Check that dependencies reference valid tasks
        for t in tasks:
            for dep in t.get("dependencies", []):
                if dep not in task_ids:
                    raise WorkflowPlanError(
                        f"Task '{t.get('task_id')}' depends on non-existent task '{dep}'"
                    )
                if dep == t.get("task_id"):
                    raise WorkflowPlanError(f"Task '{dep}' cannot depend on itself")

        # Detect circular dependencies (Cycles in DAG)
        self._detect_cycles(tasks)

    def _detect_cycles(self, tasks: List[Dict[str, Any]]) -> None:
        """Detect cycles using DFS graph coloring."""
        adj: Dict[str, List[str]] = {t["task_id"]: t.get("dependencies", []) for t in tasks}
        visited: Dict[str, int] = {}  # 0: unvisited, 1: visiting, 2: visited

        def dfs(node: str, path: List[str]) -> None:
            visited[node] = 1
            for neighbor in adj.get(node, []):
                if visited.get(neighbor, 0) == 1:
                    cycle_str = " -> ".join(path + [neighbor])
                    raise WorkflowPlanError(f"Circular dependency detected in workflow plan: {cycle_str}")
                elif visited.get(neighbor, 0) == 0:
                    dfs(neighbor, path + [neighbor])
            visited[node] = 2

        for task_id in adj:
            if visited.get(task_id, 0) == 0:
                dfs(task_id, [task_id])

    def compute_execution_order(self, tasks: List[Dict[str, Any]]) -> List[List[str]]:
        """Compute parallel execution stages using Kahn's algorithm for topological sorting."""
        in_degree: Dict[str, int] = {t["task_id"]: 0 for t in tasks}
        dependents: Dict[str, List[str]] = {t["task_id"]: [] for t in tasks}

        for t in tasks:
            t_id = t["task_id"]
            deps = t.get("dependencies", [])
            in_degree[t_id] = len(deps)
            for dep in deps:
                dependents[dep].append(t_id)

        stages: List[List[str]] = []
        # Find all initial tasks with in_degree == 0
        current_layer = [t_id for t_id, deg in in_degree.items() if deg == 0]

        while current_layer:
            current_layer.sort()  # deterministic ordering
            stages.append(current_layer)
            next_layer = []
            for t_id in current_layer:
                for dependent in dependents[t_id]:
                    in_degree[dependent] -= 1
                    if in_degree[dependent] == 0:
                        next_layer.append(dependent)
            current_layer = next_layer

        # Verify all tasks processed
        processed_count = sum(len(stage) for stage in stages)
        if processed_count != len(tasks):
            raise WorkflowPlanError("Unresolved dependency cycle prevented complete topological sorting")

        return stages

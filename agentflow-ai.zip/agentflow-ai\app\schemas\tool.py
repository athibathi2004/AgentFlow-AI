"""Pydantic schemas for Tool entities."""

from datetime import datetime
from typing import Any, Dict, Optional
from pydantic import BaseModel, ConfigDict, Field


class ToolBase(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    name: str = Field(..., description="Tool name")
    description: str = Field(..., description="Tool description")
    schema_definition: Dict[str, Any] = Field(
        ...,
        alias="schema_json",
        description="JSON Schema for parameters",
    )
    is_sensitive: bool = Field(default=False, description="Flag for sensitive operations")
    requires_approval: bool = Field(default=False, description="Requires human approval to run")
    is_enabled: bool = Field(default=True, description="Tool availability")
    is_mcp: bool = Field(default=False, description="Whether tool originates from MCP server")
    mcp_server_id: Optional[str] = Field(default=None, description="MCP server identifier")

    @property
    def schema_json(self) -> Dict[str, Any]:
        return self.schema_definition


class ToolCreate(ToolBase):
    id: str = Field(..., description="Unique tool identifier")


class ToolRead(ToolBase):
    id: str
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


class ToolExecutionRequest(BaseModel):
    parameters: Dict[str, Any] = Field(default_factory=dict, description="Input parameters matching tool schema")
    execution_id: Optional[str] = Field(default=None, description="Associated workflow execution ID")
    task_id: Optional[str] = Field(default=None, description="Associated task ID")


class ToolExecutionResponse(BaseModel):
    tool_id: str
    status: str
    result: Dict[str, Any]
    duration_seconds: float
    error: Optional[str] = None

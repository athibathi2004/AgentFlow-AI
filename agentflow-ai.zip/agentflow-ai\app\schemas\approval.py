"""Pydantic schemas for Human-in-the-Loop Approvals."""

from datetime import datetime
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field


class ApprovalRequestRead(BaseModel):
    id: str
    workflow_id: str
    execution_id: Optional[str] = None
    task_id: Optional[str] = None
    tool_id: Optional[str] = None
    request_type: str
    status: str
    details_json: Dict[str, Any]
    reviewer_notes: Optional[str] = None
    created_at: datetime
    resolved_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class ApprovalActionRequest(BaseModel):
    notes: Optional[str] = Field(default=None, description="Optional reviewer justification or comments")
